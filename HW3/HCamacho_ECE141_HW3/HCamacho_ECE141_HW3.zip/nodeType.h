#pragma once
template <class Type>
struct nodeType {
    Type info;
    nodeType<Type>* link;
};